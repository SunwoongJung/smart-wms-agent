# scoring_formula.md

# 산식 및 점수 계산 문서

## 적치 점수
보관조건 일치는 점수가 아니라 필수 조건이다. 보관조건이 불일치하는 Location은 후보 필터링 단계에서 제외되며 점수를 계산하지 않는다.

```text
stocking_score =
same_sku_score
+ capacity_score
+ distance_score
+ fast_moving_score
- congestion_penalty
```

same_sku_score:
```text
동일 SKU Location 존재 = 100
동일 SKU 없음 = 0
```

capacity_score:
```text
zone_remaining_capacity_ratio * 50
zone_remaining_capacity_ratio = (max_capacity - 점유 수량 합계) / max_capacity
```

distance_score:
```text
max(0, 50 - distance_from_gate)
distance_from_gate 단위: m
```

fast_moving_score:
```text
고회전 SKU(fast_moving_flag = 1)이고 distance_from_gate <= 20m인 Zone = 30
그 외 = 0
```

congestion_penalty:
```text
Zone 점유율 90% 초과 시 = (zone_occupied_ratio - 0.9) * 100
그 외 = 0
zone_occupied_ratio = 점유 수량 합계 / max_capacity
```

## 예상 피킹시간
```text
estimated_picking_minutes =
base_minutes
+ (line_count - 1) * 2
+ ceil(total_qty / 10) * 2
+ max_distance_from_gate / 10
```

기본값:
```text
base_minutes = 15
buffer_minutes = 10
```

- line_count: 주문의 라인(SKU) 수
- total_qty: 전체 라인 수량 합계
- max_distance_from_gate: 피킹 대상 Location 중 가장 먼 Zone의 입구 거리(m)

예시: 1개 라인, 수량 20, ZONE_A(10m) 주문은 15 + 0 + 4 + 1 = 20분이다.

## 피킹 시작시간
```text
recommended_start_time = due_datetime - estimated_picking_minutes - buffer_minutes
```

## 피킹 우선순위
```text
picking_priority_score =
deadline_urgency_score
+ customer_priority_score
+ shortage_risk_score
- estimated_picking_time_penalty
- travel_time_penalty
```

deadline_urgency_score:
```text
max(0, 120 - 출고까지 남은 분)
이미 권장 시작시간이 지난 주문 = 120 (최대값 고정, 긴급 피킹)
```

customer_priority_score:
```text
customer_priority * 10
customer_priority: 1(기본) ~ 5(최우선)
```

shortage_risk_score:
```text
주문 라인에 위험등급 HIGH SKU 포함 = 30
주문 라인에 위험등급 MEDIUM SKU 포함 = 15
그 외 = 0
```

estimated_picking_time_penalty:
```text
estimated_picking_minutes * 0.5
```

travel_time_penalty:
```text
max_distance_from_gate * 0.2
```

## 예상소진일
```text
predicted_demand = a * day_index + b
projected_inventory(t) = projected_inventory(t-1) + inbound_qty(t) - outbound_qty(t) - predicted_demand(t)
expected_stockout_date = first date where projected_inventory <= 0
```

## What-if 시뮬레이션
```text
입고 추가: projected_inventory(t)에 additional_inbound_qty를 additional_inbound_date에 가산
수요 변화: predicted_demand(t) * demand_multiplier 적용
출력: 기존 예상소진일과 변경 후 예상소진일 비교
```
