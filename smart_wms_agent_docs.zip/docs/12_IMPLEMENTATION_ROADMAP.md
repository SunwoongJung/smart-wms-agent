# 12_IMPLEMENTATION_ROADMAP.md

# Implementation Roadmap

## Phase 1. Project Setup
- Python 프로젝트 생성
- 디렉토리 구조 생성
- 환경설정
- requirements.txt
- LLM·임베딩 모델 확정 (사내 제공 모델 — 현재 미정, 코드 작성 전 필수 결정)

## Phase 2. Database & Seed
- SQLite schema
- Seed data generator
- products/zones/locations
- inventory/inbound/outbound
- demand_history

## Phase 3. Tool Engine
- 조회 Tool
- 적치 Tool
- 피킹 Tool
- Draft/Approval Tool
- Dry Run Tool

## Phase 4. Forecast
- Linear Regression
- 예상재고 계산
- 예상소진일
- 위험등급
- What-if

## Phase 5. RAG
- 정책 문서 작성
- Chunking
- Metadata
- FAISS index
- Retrieval test

## Phase 6. LangGraph
- AgentState
- Router
- Parameter Extractor
- Planner
- Tool Executor
- Verifier
- RAG Decision
- Approval Gate

## Phase 7. API
- /chat
- /recommend/stocking
- /recommend/picking
- /forecast
- /simulate
- /approve
- /trace

## Phase 8. UI
- Streamlit Chat
- Today Operations
- Approval
- Trace Viewer
- RAG Sources

## Phase 9. Evaluation
- Intent eval
- Tool eval
- RAG eval
- Forecast eval
- E2E demo

## Phase 10. Enhancement
- Hybrid Search
- Reranker
- Forecast chart
- PostgreSQL 전환
- 실제 WMS API 연동
