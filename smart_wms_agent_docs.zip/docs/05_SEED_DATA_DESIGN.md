# 05_SEED_DATA_DESIGN.md

# Seed Data Design

## 1. 목적
Agent 주요 기능을 검증할 수 있는 업무 시나리오형 Seed Data를 정의한다.

## 2. 권장 규모
| 데이터 | 규모 |
|---|---:|
| products | 50 SKU |
| zones | 5 |
| locations | 100 |
| inventory | 500 |
| inbound_orders | 50 |
| outbound_orders | 100 |
| outbound_order_lines | 180 (주문당 1~3라인) |
| demand_history | SKU당 60일 |
| shipping_pending | 20 |

## 3. 필수 테스트 SKU
| SKU | 목적 |
|---|---|
| SKU_A001 | 재고 부족 위험, Forecast 테스트 |
| SKU_A002 | 동일 SKU 적치 테스트 |
| SKU_A003 | 고회전 적치 가중치 테스트 |
| SKU_C001 | 냉장 Zone 필터 테스트 |
| SKU_F001 | 냉동 Zone 필터 테스트 |

## 4. Zone 구성
| Zone | 보관조건 | 거리 | 목적 |
|---|---|---:|---|
| ZONE_A | NORMAL | 10m | 고회전 일반품 |
| ZONE_B | NORMAL | 30m | 일반 재고 |
| ZONE_C | COLD | 20m | 냉장품 |
| ZONE_D | FROZEN | 35m | 냉동품 |
| ZONE_E | NORMAL | 60m | 저회전/보관용 |

## 5. 적치 시나리오
- 동일 SKU Location 존재: INB003/SKU_A002는 L-A-001 추천
- 동일 SKU 없음: Zone 잔여용량 기준 추천
- 고회전 SKU: 가까운 Zone 가중치 적용
- 보관조건 불일치: NORMAL Zone 제외, COLD/FROZEN만 후보
- CAPA 부족: SOP 대응 필요

## 6. 피킹 시나리오
현재시간 10:20 기준:
| Order | Due | 라인수 | 총수량 | 특이사항 | 기대 |
|---|---|---:|---:|---|---|
| ORD001 | 11:00 | 1 | 20 | ZONE_A, 권장시작 10:30 | 1순위 (출고시간 임박) |
| ORD002 | 13:00 | 2 | 25 | customer_priority=5 | 2순위 (고객 우선순위로 ORD003보다 우선) |
| ORD003 | 13:00 | 1 | 30 | customer_priority=1 | 3순위 |
| ORD004 | 15:00 | 1 | 10 | SKU_A001 포함 (HIGH 위험) | shortage_risk_score 가점 검증 |

검증 포인트:
- ORD001: 출고시간 기반 1순위와 권장시작시간 10:30 (estimated 20분 + buffer 10분)
- ORD002 vs ORD003: 동일 출고시간에서 customer_priority 반영 여부
- ORD002: 멀티라인 주문의 예상 피킹시간 계산 (line_count 반영)
- ORD004: 재고 부족 위험 SKU 가점 반영 여부

## 6.1 출고확정 시나리오
- ORD010: 피킹완료 후 출고확정대기(SHIPPING_PENDING) 상태로 생성
- Demo 8에서 Dry Run → 승인 → SHIPPED 전환을 검증한다
- shipping_pending 20건 중 ORD010을 포함하여 최소 3건은 당일 확정 대상으로 생성

## 7. 재고 리스크 시나리오
- SKU_A001: 현재재고 120, 최근 출고 증가 추세, HIGH 위험
- SKU_A004: 재고 부족이나 3일 뒤 입고예정 존재
- SKU_A005: 안정 재고, LOW 위험

## 8. Demand History 생성 패턴
- increasing
- stable
- decreasing
- seasonal
- noisy

Forecast 검증을 위해 SKU_A001은 증가 추세로 생성한다.

## 9. 산출 파일
```text
seed/products.csv
seed/zones.csv
seed/locations.csv
seed/inventory.csv
seed/inbound_orders.csv
seed/outbound_orders.csv
seed/outbound_order_lines.csv
seed/demand_history.csv
seed/picking_tasks.csv
seed/stocking_tasks.csv
seed/shipping_pending.csv
```
