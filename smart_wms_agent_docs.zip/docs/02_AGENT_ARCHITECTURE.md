# 02_AGENT_ARCHITECTURE.md

# Smart WMS Agent Architecture

## 1. 목적
LangGraph 기반 Agent Architecture를 정의한다. 본 Agent는 창고 운영 데이터를 분석하고 업무 우선순위를 추천하며, 상태 변경 전 승인 절차를 수행한다.

## 2. 전체 Workflow
조건 분기를 포함한 LangGraph 그래프 구조이다.

```text
START
  ↓
Router Node
  ↓
Parameter Extractor Node
  ├─ 필수 파라미터 누락 → Clarification 응답 (사용자 재질문) → END
  ↓
Planner Node ←──────────────┐
  ↓                         │
Tool Executor Node          │
  ↓                         │
Verifier Node               │
  ├─ 검증 실패 → 재계획 (최대 2회) ─┘
  ├─ 재계획 한도 초과 → 오류 응답 → END
  ↓ 검증 통과
RAG Decision Node
  ├─ RAG 불필요 → Response Generator Node
  ↓ RAG 필요
RAG Retriever Node
  ↓
Response Generator Node
  ↓
Approval Gate Node
  ├─ 상태변경 아님 (조회/추천/설명) → END
  ├─ 사용자 거부 → Draft REJECTED → END
  ↓ 사용자 승인
State Update Tool Node
  ↓
END
```

## 3. 적용 Agentic Pattern
| Pattern | Node | 목적 |
|---|---|---|
| Meta Controller | Router | 질의 intent 분류 |
| Planning | Planner | Tool 실행계획 생성 |
| Tool Use | Tool Executor | 조회, 추천, Forecast, 상태변경 |
| ReAct | Planner+Executor | 복합 질의에서 실행/관찰 반복 |
| PEV | Planner+Executor+Verifier | 실행 전후 오류 검증 |
| Dry Run | Approval Gate | 상태변경 전 미리보기 |
| Human-in-the-loop | Approval Gate | 사용자 승인 기반 실행 |
| Adaptive RAG | RAG Decision | 필요한 경우만 문서 검색 |
| Simulator | Forecast Tool | 미래 재고흐름 및 What-if |

## 4. Intent 체계
| Intent | 설명 | 예시 |
|---|---|---|
| daily_summary | 오늘 할 일 종합 | 오늘 뭐 해야 돼? |
| inbound_query | 입고예정 조회 | 오늘 입고예정 보여줘 |
| stocking_recommendation | 적치 추천 | INB003 적치 추천 |
| stocking_task_create | 적치지시 생성 | 적치지시 생성해줘 |
| outbound_query | 출고예정 조회 | 오늘 출고예정 보여줘 |
| picking_recommendation | 피킹 추천 | 피킹 순서 알려줘 |
| picking_instruction_create | 피킹지시 생성 | ORD001 피킹지시 생성 |
| inventory_risk | 재고 리스크 | A제품 언제 소진돼? |
| risk_response_recommendation | SOP 대응 | 부족하면 어떻게 해? |
| shipping_pending_query | 출고확정대기 조회 | 출고확정대기 보여줘 |
| shipping_confirm | 출고확정 | ORD001 출고확정 |
| policy_question | 정책/산식 질문 | 왜 Zone A야? |

## 5. Node 상세

### 5.1 Router Node
자연어 질의를 업무 intent로 분류한다. 상태변경 질문인지 조회성 질문인지 구분한다. 모든 질문에 모든 Tool을 실행하지 않도록 비용과 응답시간을 제어한다.

### 5.2 Parameter Extractor Node
질문에서 SKU, inbound_no, order_no, zone_id, location_id, target_date, action_type을 추출한다. 부족한 값이 있으면 clarification으로 분기한다.

### 5.3 Planner Node
업무 intent와 파라미터를 기준으로 Tool 실행 순서를 계획한다. 예를 들어 재고 리스크 질의는 재고조회, 출고이력조회, 입고예정조회, Forecast, 위험등급계산, SOP검색 순서로 계획한다.

### 5.4 Tool Executor Node
실제 업무 계산을 수행한다. LLM이 임의 계산하지 않도록 DB 조회, 점수 계산, Forecast, Draft 생성을 Tool로 분리한다.

### 5.5 Verifier Node
Tool 결과가 업무 규칙을 지키는지 검증한다. CAPA 초과, 보관조건 불일치, 피킹 시작시간 오류, Tool 결과와 응답 수치 불일치를 차단한다.

### 5.6 RAG Decision Node
RAG가 필요한지 판단한다. 단순 조회에는 RAG를 생략하고, 추천 근거/정책/SOP/산식 질문에만 RAG를 사용한다.

### 5.7 RAG Retriever Node
정책, 산식, SOP, 용어 문서를 검색한다. 검색 결과는 Response Generator에 전달되어 설명 근거로 사용된다.

### 5.8 Response Generator Node
결론, 수치, 근거, 산식, 정책, 권장조치, 승인 필요 여부를 포함한 최종 응답을 생성한다.

### 5.9 Approval Gate Node
적치지시, 피킹지시, 출고확정 같은 상태변경 작업 전 사용자 승인을 요구한다.

### 5.10 State Update Tool Node
승인된 Draft에 대해서만 실제 DB 상태를 변경한다.

## 6. Agent State Schema
```python
class AgentState(TypedDict):
    user_query: str
    user_id: str | None
    intent: str | None
    intent_confidence: float | None
    parameters: dict
    missing_parameters: list[str]
    plan: list[dict]
    tool_results: dict
    verification_results: dict
    rag_required: bool
    rag_queries: list[str]
    rag_context: list[dict]
    draft_actions: list[dict]
    approval_required: bool
    approval_status: str | None
    final_response: str | None
    error: str | None
```

## 7. 주요 Workflow
Tool 이름은 06_TOOL_DESIGN.md의 표준 Tool 목록을 따른다.

### Daily Summary
```text
lookup_outbound_orders (status=PLANNED, 미지시 출고)
→ recommend_picking
→ lookup_inbound_orders (status=RECEIVED, 적치대기)
→ recommend_stocking
→ scan_inventory_risk
→ lookup_shipping_pending
→ Response Generator (종합 요약 생성)
```

### Stocking Recommendation
```text
lookup_inbound_orders
→ filter_available_locations
→ check_same_sku_location
→ calculate_stocking_score
→ recommend_stocking
→ Verifier
→ RAG (stocking_policy, scoring_formula)
→ Response Generator
```

### Inventory Risk
```text
lookup_inventory
→ lookup_demand_history
→ lookup_inbound_orders (status=PLANNED, 입고예정)
→ inventory_forecast
→ calculate_inventory_risk
→ RAG (inventory_risk_policy, warehouse_operation_sop)
→ Response Generator
```

### Shipping Confirm
```text
lookup_shipping_pending
→ create_shipping_confirm_draft (Dry Run 자동 수행)
→ Approval Gate (Dry Run 결과 표시 + 승인 요청)
→ confirm_shipping
```

## 8. 설계 원칙
1. LLM은 계산하지 않는다.
2. Tool이 계산한다.
3. LLM은 결과를 설명한다.
4. RAG는 정책과 SOP 근거를 제공한다.
5. 상태 변경은 승인 후 수행한다.
6. 모든 추천은 Tool trace로 추적 가능해야 한다.

## 9. Agent 페르소나 및 응답 원칙
System Prompt에 반영할 Agent 정체성 정의이다.

| 항목 | 정의 |
|---|---|
| Agent 이름 | Smart WMS Agent |
| 주요 역할 | 창고 운영 Copilot. 업무 intent 분류, Tool 실행 결과 해석, 정책·산식 기반 근거 설명, Draft 생성과 승인 요청 |
| 핵심 목표 | 운영자가 당일 우선 처리할 업무를 빠짐없이, 근거와 함께 파악하고 안전하게 실행하도록 지원 |
| 사용 LLM | 사내 제공 모델 (미정 — 코드 작성 착수 전 반드시 확정). Router용 경량 모델과 Response Generator용 모델을 분리할 수 있도록 model-agnostic 인터페이스로 구현 |

### 톤앤매너
- 간결한 존댓말을 사용한다 ("~입니다", "~가 필요합니다").
- 결론을 먼저 말하고 근거를 뒤에 붙인다 (결론 → 수치 → 근거/산식 → 권장조치).
- 모든 수치는 Tool 결과를 그대로 인용하며, "약", "아마" 같은 추측 표현을 쓰지 않는다.
- HIGH 위험, 출고시간 임박 등 긴급 건은 응답 첫머리에 배치한다.
- 이모지, 과장 표현, 불필요한 사과를 사용하지 않는다.
- 상태변경 작업은 반드시 "승인이 필요합니다"를 명시하고 변경 내용을 요약해 보여준다.

### 응답 금지 영역
- Tool 결과 없이 재고 수량, 위치, 시간 등 수치를 생성하는 것
- RAG 문서에 없는 정책·SOP를 임의로 만들어 설명하는 것
- 승인 없이 상태변경이 완료된 것처럼 표현하는 것
- WMS 업무 범위 밖 질문에 답변하는 것 (범위 밖 질문은 지원 가능한 업무 목록을 안내)

## 10. 대화 메모리 및 세션 관리
AgentState는 단일 질의 1회 처리용이며, 멀티턴 문맥은 별도의 SessionState로 관리하여 각 턴 시작 시 AgentState에 주입한다.

### SessionState Schema
```python
class SessionState(TypedDict):
    session_id: str
    user_id: str
    history: list[dict]          # 최근 10턴 윈도우 버퍼 (질문, 응답 요약, intent)
    active_draft_ids: list[str]  # 승인 대기 중인 Draft
    last_intent: str | None
    last_entities: dict          # 최근 언급된 sku, order_no, inbound_no, zone_id
```

### 메모리 전략
| 항목 | 정의 |
|---|---|
| 메모리 유형 | 윈도우 버퍼 (최근 10턴) + 구조화 세션 슬롯 (active_draft_ids, last_entities) |
| 멀티턴 해소 | "승인해줘" → active_draft_ids 참조, "그 제품은?" → last_entities로 대명사 해소, 해소 불가 시 clarification |
| 세션 초기화 | 30분 무활동 시 세션 종료. 새 세션은 빈 history로 시작 |
| Draft 영속성 | PENDING_APPROVAL Draft는 DB(action_drafts)에 저장되어 세션과 무관하게 유지. 세션 만료 후에도 draft_id로 승인 가능 |
| 장기 메모리 | POC 범위 제외. 모든 영속 상태는 DB(action_drafts, tool_logs, rag_logs)로 관리 |
