# 03_RAG_DESIGN.md

# RAG Design

## 1. 목적
RAG는 추천 근거, 정책, 산식, SOP, 용어 설명을 제공한다. 의사결정 자체는 Tool이 수행하고, RAG는 Tool 결과를 설명할 근거를 제공한다.

## 2. RAG 적용 영역
| 영역 | 질문 | 검색 문서 |
|---|---|---|
| 적치 설명 | 왜 Zone A야? | stocking_policy.md, scoring_formula.md |
| 피킹 설명 | 왜 ORD001이 1순위야? | picking_policy.md, scoring_formula.md |
| 재고 리스크 | A제품 왜 위험해? | inventory_risk_policy.md |
| SOP 대응 | 부족하면 어떻게 해? | warehouse_operation_sop.md |
| 산식 설명 | 소진일은 어떻게 계산해? | scoring_formula.md |
| 용어 설명 | 출고확정대기가 뭐야? | wms_terms.md |

## 3. 문서 구성
- stocking_policy.md: 동일 SKU 우선, CAPA, 거리, 고회전 SKU 정책
- picking_policy.md: 출고시간, 작업시간, 버퍼, 우선순위 정책
- inventory_risk_policy.md: 예상소진일, 안전재고, 위험등급
- warehouse_operation_sop.md: 재고부족, CAPA부족, 출고임박 대응
- scoring_formula.md: 적치/피킹/Forecast 산식
- wms_terms.md: WMS 용어

## 4. Chunking 전략
| 문서 유형 | Chunk 기준 |
|---|---|
| 정책 | 정책 항목 단위 |
| SOP | 예외상황 단위 |
| 산식 | 산식 1개 단위 |
| 용어 | 용어 1~3개 단위 |

권장 Chunk Size: 800~1500 characters  
권장 Overlap: 100~200 characters

## 5. Metadata
```json
{
  "source": "stocking_policy.md",
  "document_type": "policy",
  "domain": "stocking",
  "section": "same_sku_policy",
  "version": "1.0",
  "priority": "high"
}
```

document_type: policy, sop, formula, glossary, guide  
domain: stocking, picking, inventory, shipping, common

### Section ID 매핑 규칙
Chunk는 각 문서의 `##` 헤딩 단위로 생성하며, 한국어 헤딩을 아래 표 기준의 영문 section id로 변환하여 metadata에 부여한다. 표에 없는 헤딩은 케밥/스네이크 케이스 영문으로 신규 등록한다.

| 문서 | 한국어 헤딩 | section id |
|---|---|---|
| stocking_policy.md | 동일 SKU 우선 정책 | same_sku_policy |
| stocking_policy.md | Zone 잔여용량 정책 | capacity_policy |
| stocking_policy.md | 거리 정책 | distance_policy |
| stocking_policy.md | 고회전 SKU 정책 | fast_moving_policy |
| picking_policy.md | 피킹 시작시간 | picking_start_time |
| picking_policy.md | 예상 피킹시간 | picking_time_estimation |
| picking_policy.md | 우선순위 기준 | picking_priority_policy |
| inventory_risk_policy.md | 위험등급 | risk_level |
| inventory_risk_policy.md | 데이터 부족 Fallback | forecast_fallback |
| warehouse_operation_sop.md | 재고 부족 예상 대응 | sop_stock_shortage |
| warehouse_operation_sop.md | CAPA 부족 대응 | sop_capacity_shortage |
| warehouse_operation_sop.md | 적재 가능 Location 없음 대응 | sop_no_available_location |
| warehouse_operation_sop.md | 피킹지시 미발행 대응 | sop_picking_not_issued |
| warehouse_operation_sop.md | 입고 지연 대응 | sop_inbound_delay |
| warehouse_operation_sop.md | 출고확정 지연 대응 | sop_shipping_confirm_delay |
| scoring_formula.md | 적치 점수 | stocking_score_formula |
| scoring_formula.md | 피킹 우선순위 | picking_priority_formula |
| scoring_formula.md | 예상소진일 | stockout_formula |

## 6. Retrieval Strategy
```text
1. Intent 확인
2. 검색 대상 문서군 결정
3. Query 생성
4. Metadata Filter 적용
5. Vector Search
6. Top-K 검색
7. 필요 시 Rerank
8. Response Generator로 전달
```

## 7. Adaptive RAG
RAG 생략 질문:
```text
오늘 입고예정 보여줘
A제품 현재 재고 알려줘
```
RAG 사용 질문:
```text
왜 Zone A를 추천했어?
부족하면 어떻게 대응해야 해?
피킹 시작시간은 어떻게 계산해?
```

## 8. SOP 기반 RAG
Forecast Tool이 예상소진일과 위험등급을 계산하면, RAG는 inventory_risk_policy.md와 warehouse_operation_sop.md를 검색하여 대응방안을 제공한다.

## 9. Response Grounding 원칙
최종 답변에는 Tool 결과, 적용 정책, 사용 산식, 참조 문서, 권장 조치를 포함한다. RAG 문서에 없는 정책을 임의로 생성하지 않는다.

## 10. 임베딩 및 Vector Store
| 항목 | 정의 |
|---|---|
| Vector DB | FAISS (POC). 향후 PostgreSQL/pgvector 전환 가능 |
| 임베딩 모델 | 사내 제공 모델 (미정 — Phase 5 RAG 구현 착수 전 반드시 확정) |
| 모델 요구사항 | 한국어 문서 검색 지원, 모델 교체가 가능하도록 임베딩 인터페이스 추상화 (인덱스 재생성 스크립트 포함) |
| 인덱스 갱신 | 정책 문서 변경 시 전체 재인덱싱 (POC 규모에서 충분) |

대화 이력은 RAG 대상이 아니다. 문서 검색은 RAG, 대화 문맥은 세션 메모리(02_AGENT_ARCHITECTURE.md §10)로 분리하여 관리한다.

## 11. 평가 기준
| 지표 | 목표 |
|---|---|
| Recall@3 | 85% 이상 |
| Source Accuracy | 90% 이상 |
| Groundedness | 90% 이상 |
| Formula Retrieval Accuracy | 90% 이상 |
| SOP Retrieval Accuracy | 85% 이상 |
