# 08_API_SPEC.md

# API Specification

## 1. 공통 응답
```json
{
  "success": true,
  "run_id": "RUN-001",
  "data": {},
  "message": "처리 완료",
  "tool_trace": [],
  "rag_sources": []
}
```

## 2. POST /chat
자연어 질의 처리.
```json
{"user_query":"오늘 뭐 해야 돼?","user_id":"operator01"}
```

## 3. GET /inbound
입고예정/적치대기 조회.

## 4. POST /recommend/stocking
```json
{"inbound_no":"INB003"}
```

## 5. POST /stocking/draft
적치지시 Draft 생성.

## 6. GET /outbound
출고예정 조회. 주문 헤더와 라인(outbound_order_lines)을 함께 반환한다.
```json
{
  "order_no":"ORD002",
  "due_datetime":"2026-06-11 13:00",
  "customer_priority":5,
  "status":"PLANNED",
  "lines":[
    {"sku":"SKU_A002","qty":15},
    {"sku":"SKU_A003","qty":10}
  ]
}
```

## 7. POST /recommend/picking
```json
{"current_datetime":"2026-06-11 10:20"}
```

## 8. POST /picking/draft
피킹지시 Draft 생성.

## 9. POST /forecast
```json
{"sku":"SKU_A001","forecast_days":30}
```

## 10. POST /risk/scan
전체 SKU 리스크 스캔.

## 11. POST /simulate/stockout
```json
{
  "sku":"SKU_A001",
  "additional_inbound_qty":100,
  "additional_inbound_date":"2026-06-15",
  "demand_multiplier":1.0
}
```

## 12. GET /shipping/pending
출고확정대기 조회.

## 12.1 POST /shipping/draft
출고확정 Draft 생성. 생성 시 Dry Run을 자동 수행하여 변경 미리보기를 함께 반환한다.
```json
{"order_no":"ORD010"}
```
응답:
```json
{
  "draft_id":"DRF-SHP-001",
  "dry_run":{
    "changes":[
      {"table":"outbound_orders","field":"status","before":"SHIPPING_PENDING","after":"SHIPPED"},
      {"table":"inventory","sku":"SKU_A002","qty_change":-20}
    ],
    "warnings":[]
  },
  "approval_required":true
}
```

## 13. POST /approve
Draft 승인 및 실행.
```json
{"draft_id":"DRF-PCK-001","approved":true,"user_id":"operator01"}
```

## 14. GET /trace/{run_id}
Agent 실행 trace 조회.
