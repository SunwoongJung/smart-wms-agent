# 07_FORECAST_AND_SIMULATION.md

# Forecast & Simulation Design

## 1. 목적
과거 출고이력을 활용하여 SKU별 예상소진일과 위험등급을 계산한다. What-if 조건을 반영하여 입고 추가 또는 수요 증가 시 소진일 변화를 시뮬레이션한다.

## 2. 입력 데이터
- inventory
- demand_history
- inbound_orders
- outbound_orders
- products.safety_stock

## 3. Linear Regression
```text
x = day_index
y = shipped_qty
predicted_demand = a * day_index + b
```

## 4. 예상재고
```text
projected_inventory(t) =
projected_inventory(t-1)
+ planned_inbound_qty(t)
- confirmed_outbound_qty(t)
- predicted_demand(t)
```

## 5. 예상소진일
```text
first date where projected_inventory <= 0
```

## 6. 안전재고 도달일
```text
first date where projected_inventory <= safety_stock
```

## 7. 위험등급
| 등급 | 기준 |
|---|---|
| HIGH | 7일 이내 소진 |
| MEDIUM | 14일 이내 소진 |
| LOW | 14일 초과 또는 소진 없음 |
| WATCH | 안전재고 이하 도달 |

## 8. Fallback
- 30일 이상: Linear Regression
- 14일 이상: 14일 이동평균
- 7일 이상: 7일 이동평균
- 7일 미만: 예측 불가

## 9. What-if
simulate_stockout Tool로 수행한다 (06_TOOL_DESIGN.md 참조).

질문 예:
```text
6/15에 A제품 100개 입고되면?
출고량이 20% 증가하면?
```
출력:
```text
기존 예상소진일: 2026-06-18
변경 후 예상소진일: 2026-06-24
소진일 6일 연장
```

## 10. 한계와 확장
Linear Regression은 단순 추세 예측에 적합하지만 계절성, 프로모션, 갑작스러운 대량 출고에는 약하다. 향후 Prophet, XGBoost, 시계열 모델로 확장 가능하다.
