# 06_TOOL_DESIGN.md

# Tool Design

## 1. 목적
Tool은 WMS 조회, 추천 계산, Forecast, Draft 생성, 상태변경을 담당한다. LLM은 계산하지 않고 Tool 결과를 해석한다.

## 2. 설계 원칙
- 입력/출력은 JSON 표준
- Tool은 deterministic
- 상태변경 Tool은 승인 후 실행
- 모든 Tool 실행은 tool_logs 저장

## 3. 표준 Tool 목록
본 문서가 Tool 이름의 단일 기준이다. 다른 문서(02 Architecture, 10 Evaluation 등)는 아래 이름을 그대로 사용한다.

| 분류 | Tool | 상태변경 |
|---|---|---|
| 조회 | lookup_inventory | X |
| 조회 | lookup_inbound_orders | X |
| 조회 | lookup_outbound_orders | X |
| 조회 | lookup_shipping_pending | X |
| 조회 | lookup_demand_history | X |
| 적치 | filter_available_locations | X |
| 적치 | check_same_sku_location | X |
| 적치 | calculate_stocking_score | X |
| 적치 | recommend_stocking | X |
| 피킹 | calculate_picking_required_time | X |
| 피킹 | recommend_picking | X |
| Forecast | inventory_forecast | X |
| Forecast | calculate_inventory_risk | X |
| Forecast | scan_inventory_risk | X |
| Forecast | simulate_stockout | X |
| Draft | create_stocking_task_draft | X (Draft 생성만) |
| Draft | create_picking_instruction_draft | X (Draft 생성만) |
| Draft | create_shipping_confirm_draft | X (Draft 생성만) |
| Draft | dry_run_action | X (미리보기만) |
| 실행 | approve_action | O |
| 실행 | issue_picking_instruction | O |
| 실행 | issue_stocking_task | O |
| 실행 | confirm_shipping | O |

## 4. 조회 Tool

### lookup_inventory
SKU 기준 현재 재고 조회.
```json
{"sku":"SKU_A001"}
```

### lookup_inbound_orders
입고예정/적치대기 조회. status 필터로 용도를 구분한다.
```json
{"status":["PLANNED","RECEIVED"],"target_date":"2026-06-11"}
```
- 입고예정 조회: status = PLANNED
- 적치대기 조회: status = RECEIVED
- 입고 지연 탐지: status = PLANNED AND expected_date < today

### lookup_outbound_orders
출고예정/미지시 출고 조회. 주문 헤더와 라인을 함께 반환한다.
```json
{"status":["PLANNED"],"target_date":"2026-06-11"}
```
- 미지시 출고(피킹지시 필요) 조회: status = PLANNED

### lookup_shipping_pending
출고확정대기 조회.
```json
{"status":"PENDING"}
```

### lookup_demand_history
SKU별 과거 일자별 출고량 조회. Forecast 입력으로 사용한다.
```json
{"sku":"SKU_A001","days":60}
```

## 5. 적치 Tool

### filter_available_locations
조건:
```text
available_flag = 1
Product.storage_type = Zone.storage_type
capacity - occupied_qty >= inbound_qty
```

### check_same_sku_location
동일 SKU가 보관 중인 Location/Zone 존재 여부를 확인한다.
```json
{"sku":"SKU_A002"}
```

### calculate_stocking_score
후보 Location별 적치 점수를 계산한다. 산식은 scoring_formula.md를 따른다.
```text
stocking_score = same_sku_score + capacity_score + distance_score + fast_moving_score - congestion_penalty
```

### recommend_stocking
filter_available_locations → check_same_sku_location → calculate_stocking_score를 종합하여 최종 추천한다.
```json
{"inbound_no":"INB003"}
```
출력:
```json
{
  "recommended_location_id":"L-A-001",
  "score":183.5,
  "reasons":["동일 SKU 존재","잔여 CAPA 충분","입구 거리 우수"],
  "candidates":[],
  "approval_required":true
}
```

## 6. 피킹 Tool

### calculate_picking_required_time
멀티라인 주문 기준 예상 피킹시간 계산. 기본값 base_minutes = 15, buffer_minutes = 10.
```text
estimated_minutes = base_minutes + (line_count - 1) * 2 + ceil(total_qty / 10) * 2 + max_distance_from_gate / 10
```

### recommend_picking
미지시 출고 주문의 우선순위와 권장 시작시간을 계산한다.
```json
{"current_datetime":"2026-06-11 10:20"}
```
권장 시작시간:
```text
recommended_start_time = due_datetime - estimated_minutes - buffer_minutes
```
우선순위 점수는 scoring_formula.md의 picking_priority_score를 따른다.

## 7. Forecast Tool

### inventory_forecast
```json
{"sku":"SKU_A001","forecast_days":30}
```
처리:
```text
demand_history 조회
Linear Regression 학습 (데이터 부족 시 이동평균 fallback)
향후 forecast_days일 예측
현재재고 + 입고예정 - 출고예정 - 예측출고 누적
예상소진일, 안전재고 도달일 산출
```

### calculate_inventory_risk
inventory_forecast 결과로 위험등급을 판정한다.
```text
HIGH: 7일 이내 소진
MEDIUM: 14일 이내 소진
LOW: 14일 초과 또는 소진 없음
WATCH: 소진은 아니지만 안전재고 이하 도달
```

### scan_inventory_risk
전체 SKU에 대해 inventory_forecast + calculate_inventory_risk를 일괄 수행한다. Daily Summary와 /risk/scan에서 사용한다.
```json
{"risk_levels":["HIGH","MEDIUM","WATCH"]}
```

### simulate_stockout
What-if 시뮬레이션. 입고 추가 또는 수요 변화 조건을 반영하여 소진일 변화를 계산한다.
```json
{
  "sku":"SKU_A001",
  "additional_inbound_qty":100,
  "additional_inbound_date":"2026-06-15",
  "demand_multiplier":1.0
}
```
출력:
```json
{
  "baseline_stockout_date":"2026-06-18",
  "simulated_stockout_date":"2026-06-24",
  "delta_days":6
}
```

## 8. Draft / Approval Tool

### create_stocking_task_draft
적치지시 Draft 생성. action_drafts에 PENDING_APPROVAL로 저장한다.

### create_picking_instruction_draft
피킹지시 Draft 생성.

### create_shipping_confirm_draft
출고확정 Draft 생성. 생성 시 dry_run_action을 자동 수행하여 dry_run_result_json에 저장한다.

### dry_run_action
Draft의 상태변경 결과를 실제 반영 없이 미리 계산한다.
```json
{"draft_id":"DRF-SHP-001"}
```
출력 예 (출고확정):
```json
{
  "order_no":"ORD010",
  "changes":[
    {"table":"outbound_orders","field":"status","before":"SHIPPING_PENDING","after":"SHIPPED"},
    {"table":"inventory","sku":"SKU_A002","qty_change":-20}
  ],
  "warnings":[]
}
```

### approve_action
사용자 승인을 기록하고 해당 실행 Tool을 호출한다. 승인 없는 Draft는 실행되지 않는다.

### issue_picking_instruction / issue_stocking_task / confirm_shipping
승인된 Draft에 대해서만 실제 상태를 변경한다.

## 9. Tool 입출력 스키마 요약
모든 Tool은 JSON 입출력을 사용하며, 공통적으로 `success: bool`, `error: str | null`을 포함한다. 아래는 Tool별 입력 파라미터와 주요 출력 키이다.

| Tool | 입력 파라미터 | 주요 출력 |
|---|---|---|
| lookup_inventory | sku: str | inventory: list[{location_id, lot_no, qty, expiry_date}], total_qty: int |
| lookup_inbound_orders | status: list[str], target_date?: str | orders: list[{inbound_no, sku, qty, expected_date, status}] |
| lookup_outbound_orders | status: list[str], target_date?: str | orders: list[{order_no, due_datetime, customer_priority, status, lines: list[{sku, qty}]}] |
| lookup_shipping_pending | status?: str | pending: list[{order_no, ready_datetime, status}] |
| lookup_demand_history | sku: str, days: int | history: list[{demand_date, shipped_qty}], days_available: int |
| filter_available_locations | sku: str, inbound_qty: int | candidates: list[{location_id, zone_id, remaining_capacity}] |
| check_same_sku_location | sku: str | exists: bool, locations: list[str], zones: list[str] |
| calculate_stocking_score | sku: str, candidates: list[str] | scores: list[{location_id, score, breakdown: dict}] |
| recommend_stocking | inbound_no: str | recommended_location_id: str, score: float, reasons: list[str], candidates: list, approval_required: bool |
| calculate_picking_required_time | order_no: str | estimated_minutes: int, line_count: int, total_qty: int, max_distance: float |
| recommend_picking | current_datetime: str | recommendations: list[{order_no, priority_rank, recommended_start_time, estimated_minutes, urgent: bool}] |
| inventory_forecast | sku: str, forecast_days: int | expected_stockout_date: str\|null, safety_stock_reach_date: str\|null, daily_projection: list, method: "linear_regression"\|"ma_14"\|"ma_7"\|"insufficient_data" |
| calculate_inventory_risk | sku: str | risk_level: "HIGH"\|"MEDIUM"\|"LOW"\|"WATCH", expected_stockout_date: str\|null |
| scan_inventory_risk | risk_levels?: list[str] | risks: list[{sku, risk_level, expected_stockout_date}] |
| simulate_stockout | sku: str, additional_inbound_qty?: int, additional_inbound_date?: str, demand_multiplier?: float | baseline_stockout_date: str, simulated_stockout_date: str, delta_days: int |
| create_stocking_task_draft | inbound_no: str, location_id: str | draft_id: str, status: "PENDING_APPROVAL" |
| create_picking_instruction_draft | order_no: str | draft_id: str, status: "PENDING_APPROVAL" |
| create_shipping_confirm_draft | order_no: str | draft_id: str, dry_run: dict, status: "PENDING_APPROVAL" |
| dry_run_action | draft_id: str | changes: list[{table, field, before, after}], warnings: list[str] |
| approve_action | draft_id: str, approved: bool, user_id: str | status: "EXECUTED"\|"REJECTED", executed_action: dict\|null |
| issue_picking_instruction | draft_id: str | picking_task_id: str, order_status: "PICKING_ISSUED" |
| issue_stocking_task | draft_id: str | stocking_task_id: str, inbound_status: "STOCKING_TASK_CREATED" |
| confirm_shipping | draft_id: str | order_status: "SHIPPED", inventory_changes: list |

## 10. 예외 처리
| 예외 | 처리 |
|---|---|
| SKU 없음 | 사용자 확인 요청 (clarification) |
| 적재 가능 Location 없음 | SOP 검색 (적재 가능 Location 없음 대응) |
| CAPA 부족 | SOP 검색 (CAPA 부족 대응) |
| Forecast 데이터 7일 미만 | 예측 불가, 데이터 부족 안내 |
| Forecast 데이터 7~29일 | 이동평균 fallback (7일/14일) |
| 승인 없음 | Draft 상태 유지 |
| Dry Run 경고 존재 | 경고 표시 후 사용자 판단 위임 |
