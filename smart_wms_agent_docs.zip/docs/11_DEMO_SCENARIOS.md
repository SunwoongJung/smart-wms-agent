# 11_DEMO_SCENARIOS.md

# Demo Scenarios

## Demo 1: 오늘 뭐 해야 돼?
기대:
- 피킹 필요
- 적치 필요
- 재고 위험
- 출고확정대기

## Demo 2: INB003 적치 추천
기대:
- 추천 Location
- 점수
- 동일 SKU/CAPA/거리 근거
- 승인 요청

## Demo 3: 왜 Zone A야?
기대:
- stocking_policy.md
- scoring_formula.md
- 적용 데이터 설명

## Demo 4: 오늘 피킹해야 할 것 알려줘
기대:
- ORD001 1순위
- 권장 시작시간 10:30

## Demo 5: SKU_A001 언제 소진돼?
기대:
- Linear Regression
- 예상소진일
- 위험등급 HIGH

## Demo 6: 부족하면 어떻게 대응해?
기대:
- inventory_risk_policy.md
- warehouse_operation_sop.md
- 입고예정 확인, 긴급보충 검토

## Demo 7: ORD001 피킹지시 생성해줘
기대:
- Draft 생성
- 승인 요청
- 승인 후 PICKING_ISSUED

## Demo 8: ORD010 출고확정해줘
기대:
- Dry Run
- 승인 요청
- 승인 후 SHIPPED

## Demo 9: 6/15에 SKU_A001 100개 입고되면?
기대:
- 기존 소진일과 변경 소진일 비교
