# 09_UI_DESIGN.md

# UI Design

## 1. 목적
Streamlit 기반 UI를 설계한다. 운영자는 자연어 질문, 업무 대시보드, 추천 결과, 승인 버튼, Tool Trace, RAG 근거를 확인한다.

## 2. 메뉴
- Agent Chat
- Today Operations
- Inbound & Stocking
- Outbound & Picking
- Inventory Risk
- Shipping Confirmation
- Trace & Logs
- Policy Documents

## 3. Agent Chat
자연어 입력과 응답을 제공한다.
예:
```text
오늘 뭐 해야 돼?
A제품 언제 소진돼?
INB003 적치 추천해줘
```

## 4. Today Operations
| 구분 | 대상 | 권장시간 | 상태 | Action |
|---|---|---|---|---|
| 피킹 | ORD001 | 10:30 | 추천 | 지시 생성 |
| 재고위험 | SKU_A001 | 6/18 소진 | HIGH | 대응 보기 |
| 적치 | INB003 | 즉시 | 추천 | 지시 생성 |
| 출고확정 | ORD010 | 즉시 | 대기 | 확정 |

## 5. 적치 추천 화면
- 입고번호
- SKU
- 추천 Zone/Location
- 점수
- 추천사유
- 적치지시 생성 버튼

## 6. 피킹 추천 화면
- 주문번호
- 출고시간
- 예상작업시간
- 권장시작시간
- 우선순위
- 피킹지시 생성 버튼

## 7. 재고 리스크 화면
- SKU
- 현재재고
- 안전재고
- 예상소진일
- 위험등급
- SOP 대응
- 과거/예측 차트

## 7.1 출고확정 화면
- 주문번호
- 출고확정대기 도래시간
- Dry Run 변경 미리보기 (상태 전환, 재고 차감)
- 경고 사항
- 출고확정 버튼 (승인)

## 8. Trace 화면
- run_id
- intent
- Tool input/output
- RAG sources
- Verifier 결과
- 승인 여부

## 9. MVP 우선순위
1. Agent Chat
2. Today Operations
3. Approval 버튼
4. Tool Trace
5. Inventory Risk 상세
