# 10_EVALUATION_PLAN.md

# Evaluation Plan

## 1. 평가 영역
- Intent 평가
- Tool Selection 평가
- Rule Compliance 평가
- Forecast 평가
- RAG 평가
- Approval 평가
- E2E 평가

## 2. Intent 평가
질문 100건 기준. 목표 Accuracy 95% 이상.

## 3. Tool Selection 평가
예: 재고 리스크 질문은 lookup_inventory, lookup_demand_history, inventory_forecast, calculate_inventory_risk가 선택되어야 한다. 목표 95% 이상.

## 4. Rule Compliance
### 적치
- 보관조건 불일치 추천 0건
- CAPA 부족 추천 0건
- 동일 SKU 우선 적용 95% 이상

### 피킹
- 출고시간 반영 100%
- 작업시간 반영 95% 이상
- 시작시간 계산 정확도 100%

## 5. Forecast 평가
- MAE
- Stockout Date Error
- Risk Classification Accuracy
- Forecast Coverage

## 6. RAG 평가
| 지표 | 목표 |
|---|---|
| Recall@3 | 85% 이상 |
| Source Accuracy | 90% 이상 |
| Groundedness | 90% 이상 |
| Formula Retrieval Accuracy | 90% 이상 |
| SOP Retrieval Accuracy | 85% 이상 |

## 7. Approval 평가
- 승인 없는 적치지시 생성 0건
- 승인 없는 피킹지시 생성 0건
- 승인 없는 출고확정 0건

## 8. 실패 케이스 기록
```json
{
  "case_id":"FAIL-001",
  "query":"A제품 위험해?",
  "failure_type":"RAG_ERROR",
  "expected":"inventory_risk_policy.md",
  "actual":"stocking_policy.md",
  "fix":"metadata filter 강화"
}
```
